Figure 10:

Main file: cyprus_inf.m

Uses mobility data between the 5 cities in Cyprus (Cyprus_mobility.csv), the time series of incidences in the 5 cities in Cyprus (tmp_CY.csv) and uses the algorithm by Li et al Science (2020) to calculate the weekly value of Rt