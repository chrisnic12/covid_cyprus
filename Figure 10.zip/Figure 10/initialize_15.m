function [x,paramax,paramin]=initialize_15(pop,num_ens)
%Initialize the metapopulation SEIRS model
load M_CY %load mobility
M = 0.1*M;
load predict_results_14
num_loc=size(pop,1);
% num_var=5*num_loc+6;
% S,E,Is,Ia,obs,...,beta,mu,theta,Z,alpha,D
% prior range
Slow=1.0;Sup=1.0;%susceptible fraction
Elow=0;Eup=0;%exposed
Irlow=0;Irup=0;%documented infection
Iulow=0;Iuup=0;%undocumented infection
obslow=0;obsup=0;%reported case
betalow=0;betaup=0.8;%transmission rate
mulow=0.2;muup=1.0;%relative transmissibility
thetalow=1;thetaup=1.75;%movement factor
Zlow=3;Zup=4;%latency period
alphalow=0.3;alphaup=0.9;%reporting rate
Dlow=3;Dup=4;%infectious period
xmin=[];
xmax=[];
for i=1:num_loc
    xmin=[xmin;Slow*pop(i);Elow*pop(i);Irlow*pop(i);Iulow*pop(i);obslow];
    xmax=[xmax;Sup*pop(i);Eup*pop(i);Irup*pop(i);Iuup*pop(i);obsup];
end
xmin=[xmin;betalow;mulow;thetalow;Zlow;alphalow;Dlow];
xmax=[xmax;betaup;muup;thetaup;Zup;alphaup;Dup];
paramax=xmax(end-5:end);
paramin=xmin(end-5:end);


%Latin Hypercubic Sampling
x=lhsu(xmin,xmax,num_ens);
x=x';
for i=1:num_loc
    x((i-1)*5+1:(i-1)*5+4,:)=round(x((i-1)*5+1:(i-1)*5+4,:));
end

x(1:end-6,:)=repmat(mean(predict_results(:,:,7),2),1,300);

function s=lhsu(xmin,xmax,nsample)
nvar=length(xmin);
ran=rand(nsample,nvar);
s=zeros(nsample,nvar);
for j=1: nvar
   idx=randperm(nsample);
   P =(idx'-ran(:,j))/nsample;
   s(:,j) = xmin(j) + P.* (xmax(j)-xmin(j));
end
