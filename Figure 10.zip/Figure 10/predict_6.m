function predict_6()

%Inference for the metapopulation SEIR model
%Programmed by Sen Pei
load M_CY %load mobility
M=0.1*M;
load pop_CY %load population
Td=9;%average reporting delay
a=1.85;%shape parameter of gamma distribution
b=Td/a;%scale parameter of gamma distribution
rnds=ceil(gamrnd(a,b,1e4,1));%pre-generate gamma random numbers
num_loc=size(M,1);%number of locations
%observation operator: obs=Hx
H=zeros(num_loc,5*num_loc+6);
for i=1:num_loc
    H(i,(i-1)*5+5)=1;
end
load incidence_6 %load observation
num_times=size(incidence,1);
num_ens=1;%number of ensemble
pop0=pop*ones(1,num_ens);
[x,paramax,paramin]=initialize_predict_6(pop0,num_ens);%get parameter range
num_var=size(x,1);%number of state variables

num_real = 1000
lambda=1.1
predict_results = zeros(num_var-6,num_real,num_times);

for n=1:num_real

    [x,~,~]=initialize_predict_6(pop0,num_ens);
    pop=pop0;
    %obs_temp=zeros(num_loc,num_ens,num_times);%records of reported cases
    for t=1:num_times
         x=mean(x,2)*ones(1,num_ens)+lambda*(x-mean(x,2)*ones(1,num_ens));
        [x,pop]=SEIR(x,M,pop,t,pop0);
        predict_results(:,n,t) = x(1:end-6);
    end
   
end

save ('predict_results_6','predict_results');