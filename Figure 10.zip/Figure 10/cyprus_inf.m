
clear all
close all
clc
filename = 'tmp_CY_0924.csv'
Rep_num = zeros(14,300);
alpha = zeros(14,300);

weeks=[46 52;52 58; 58 64;64 70;70 76;76 82;82 88;88 94;94 100;100 106;106 112;112 118;118 124;124 130;130 136;136 142;142 148;148 154;154 160;160 166;166 172;172 178;178 184;184 190;190 196;196 202;202 208;208 214;214 220;220 226;226 232;232 238;238 244] ;
Wname=["05/03-11/03";"11/03-17/03";"17/03-23/03";"23/03-29/03";"29/03-04/04";"04/04-10/04";"10/04-16/04";"16/04-22/04";"22/04-28/04";"28/04-04/05";"04/05-10/05";"10/05-16/05";"16/05-22/05";"22/05-28/05";"28/05-02/06";"02/06-08/06";"08/06-14/06";"14/06-20/06";"20/06-26/06";"26/06-02/07";"02/07-08/07";"08/07-14/07";"14/07-20/07";"20/07-26/07";"26/07-01/08";"01/08-07/08";"07/08-13/08";"13/08-19/08";"19/08-25/08";"25/08-31/08";"31/08-06/09";"06/09-12/09";"12/09-18/09"]

mobility = readtable('Cyprus_mobility.csv');
cities = unique(table2cell(mobility(:,1)));
save cities_CY cities

mobility.From = string(mobility.From);
mobility.To = string(mobility.To);



pop = [46629;143192;235330;326980;88276];
save pop_CY pop

M=zeros(5,5,14);
for i=1:length(mobility.To)
    
    l = find(cities==mobility.From(i));
    k = find(cities==mobility.To(i));
        M(l,k,:)= mobility.Number(i);
end
save M_CY M

%1st week
w=1
inc = readtable(filename,'ReadVariableNames',true);
inc.Country_Region = string(inc.Country_Region);
incidence = zeros(7,5);
incidence_cum = zeros(7,5); 
%first 14 days
ct = string(cities)
for i=1:5
    l = find(inc.Country_Region==ct(i));
    
    incidence_cum(:,i)=table2array(inc(l,(weeks(w,1):weeks(w,2))));
end

for i=2:7
    incidence(i,:) = incidence_cum(i,:)-incidence_cum(i-1,:);
end
save incidence_1 incidence


inference()
load parameters_1
parameters
Re=parameters(5)*parameters(1)*parameters(6) + (1-parameters(5))*parameters(2)*parameters(1)*parameters(6)
load x_post_1
par_post = mean(x_post(end-5:end,:,:),3);
Re=par_post(5,:).*par_post(1,:).*par_post(6,:) + (1-par_post(5,:)).*par_post(2,:).*par_post(1,:).*par_post(6,:);
mean(Re)

figure
subplot(3,1,1)
histogram(par_post(1,:))
subplot(3,1,2)
histogram(par_post(5,:))
subplot(3,1,3)
histogram(Re)



%Create Data
Rep_num(w,:) = Re;
alpha(w,:)=par_post(5,:);


%run SEIR with the parameters
predict()
load predict_results_1






%2nd 7 days
w=2
a=incidence(end,:)
inc = readtable(filename,'ReadVariableNames',true);
inc.Country_Region = string(inc.Country_Region);
incidence = zeros(7,5);
incidence(1,:)=a;
incidence_cum = zeros(7,5) ;
ct = string(cities);
for i=1:5
    l = find(inc.Country_Region==ct(i));
    
    incidence_cum(:,i)=table2array(inc(l,(weeks(w,1):weeks(w,2))));
end

for i=2:7
    incidence(i,:) = incidence_cum(i,:)-incidence_cum(i-1,:);
end
save incidence_2 incidence




%initialization
inference_2()


load parameters_2
 Re=parameters(5)*parameters(1)*parameters(6) + (1-parameters(5))*parameters(2)*parameters(1)*parameters(6)
parameters
 load x_post_2
 par_post = mean(x_post(end-5:end,:,:),3);
 Re=par_post(5,:).*par_post(1,:).*par_post(6,:) + (1-par_post(5,:)).*par_post(2,:).*par_post(1,:).*par_post(6,:);
 mean(Re)

figure
subplot(3,1,1)
histogram(par_post(1,:))
subplot(3,1,2)
histogram(par_post(5,:))
subplot(3,1,3)
histogram(Re)




%Create Data
Rep_num(w,:) = Re;
alpha(w,:)=par_post(5,:);





%run SEIR with the parameters
predict_2()
load predict_results_2






load incidence_2 
%3rd week 
w=3
a=incidence(end,:)
inc = readtable(filename,'ReadVariableNames',true);
inc.Country_Region = string(inc.Country_Region);
incidence = zeros(7,5);
incidence(1,:)=a;
incidence_cum = zeros(7,5) ;

ct = string(cities)
for i=1:5
    l = find(inc.Country_Region==ct(i));
    
    incidence_cum(:,i)=table2array(inc(l,(weeks(w,1):weeks(w,2))));
end

for i=2:7
    incidence(i,:) = incidence_cum(i,:)-incidence_cum(i-1,:);
end
save incidence_3 incidence




%initialization
inference_3()


load parameters_3
 Re=parameters(5)*parameters(1)*parameters(6) + (1-parameters(5))*parameters(2)*parameters(1)*parameters(6)
parameters
 load x_post_3
 par_post = mean(x_post(end-5:end,:,:),3);

 Re=par_post(5,:).*par_post(1,:).*par_post(6,:) + (1-par_post(5,:)).*par_post(2,:).*par_post(1,:).*par_post(6,:);
 mean(Re)

figure
subplot(3,1,1)
histogram(par_post(1,:))
subplot(3,1,2)
histogram(par_post(5,:))
subplot(3,1,3)
histogram(Re)


%Create Data
Rep_num(w,:) = Re;
alpha(w,:)=par_post(5,:);


%run SEIR with the parameters
predict_3()
load predict_results_3


load incidence_3
%4rd week 
w=4
a=incidence(end,:)
inc = readtable(filename,'ReadVariableNames',true);
inc.Country_Region = string(inc.Country_Region);
incidence = zeros(7,5);
incidence(1,:)=a;
incidence_cum = zeros(7,5) ;

ct = string(cities);
for i=1:5
    l = find(inc.Country_Region==ct(i));
    
    incidence_cum(:,i)=table2array(inc(l,(weeks(w,1):weeks(w,2))));
end

for i=2:7
    incidence(i,:) = incidence_cum(i,:)-incidence_cum(i-1,:);
end
save incidence_4 incidence

%initialization
inference_4()


load parameters_4
 Re=parameters(5)*parameters(1)*parameters(6) + (1-parameters(5))*parameters(2)*parameters(1)*parameters(6)
parameters
 load x_post_4
 par_post = mean(x_post(end-5:end,:,:),3);

 Re=par_post(5,:).*par_post(1,:).*par_post(6,:) + (1-par_post(5,:)).*par_post(2,:).*par_post(1,:).*par_post(6,:);
 mean(Re)

figure
subplot(3,1,1)
histogram(par_post(1,:))
subplot(3,1,2)
histogram(par_post(5,:))
subplot(3,1,3)
histogram(Re)

%Create Data
Rep_num(w,:) = Re;
alpha(w,:)=par_post(5,:);


%run SEIR with the parameters
predict_4()
load predict_results_4



%5th week
load incidence_4
w=5
a=incidence(end,:)
inc = readtable(filename,'ReadVariableNames',true);
inc.Country_Region = string(inc.Country_Region);
incidence = zeros(7,5);
incidence(1,:)=a;
incidence_cum = zeros(7,5) ;

ct = string(cities);
for i=1:5
    l = find(inc.Country_Region==ct(i));
    
    incidence_cum(:,i)=table2array(inc(l,(weeks(w,1):weeks(w,2))));
end

for i=2:7
    incidence(i,:) = incidence_cum(i,:)-incidence_cum(i-1,:);
end
save incidence_5 incidence


%initialization
inference_5()


load parameters_5
 Re=parameters(5)*parameters(1)*parameters(6) + (1-parameters(5))*parameters(2)*parameters(1)*parameters(6)
parameters
 load x_post_5
 par_post = mean(x_post(end-5:end,:,:),3);

 Re=par_post(5,:).*par_post(1,:).*par_post(6,:) + (1-par_post(5,:)).*par_post(2,:).*par_post(1,:).*par_post(6,:);
 mean(Re)

figure
subplot(3,1,1)
histogram(par_post(1,:))
subplot(3,1,2)
histogram(par_post(5,:))
subplot(3,1,3)
histogram(Re)

%Create Data
Rep_num(w,:) = Re;
alpha(w,:)=par_post(5,:);


%run SEIR with the parameters
predict_5()
load predict_results_5
                    % Create Data
%SEM = std(Re)/sqrt(length(Re));               % Standard Error
%ts = tinv([0.025  0.975],length(Re)-1);      % T-Score
%CI = mean(Re) + ts*SEM;      
%Rep_num(5,1) = mean(Re);
%Rep_num(5,2:3) = CI


%SEM = std(par_post(5,:))/sqrt(length(par_post(5,:)));               % Standard Error
%ts = tinv([0.025  0.975],length(par_post(5,:))-1);      % T-Score
%CI = mean(par_post(5,:)) + ts*SEM;      
%alpha(5,1) = mean(par_post(5,:));
%alpha(5,2:3) = CI


%quantile(Re,[0.025,0.975]);





%6th week
load incidence_5
w=6
a=incidence(end,:);
inc = readtable(filename,'ReadVariableNames',true);
inc.Country_Region = string(inc.Country_Region);
incidence = zeros(7,5);
incidence(1,:)=a;
incidence_cum = zeros(7,5) ;

ct = string(cities)
for i=1:5
    l = find(inc.Country_Region==ct(i));
    
    incidence_cum(:,i)=table2array(inc(l,(weeks(w,1):weeks(w,2))));
end

for i=2:7
    incidence(i,:) = incidence_cum(i,:)-incidence_cum(i-1,:);
end
save incidence_6 incidence


%initialization
inference_6()


load parameters_6
 Re=parameters(5)*parameters(1)*parameters(6) + (1-parameters(5))*parameters(2)*parameters(1)*parameters(6)
parameters
 load x_post_6
 par_post = mean(x_post(end-5:end,:,:),3);

 Re=par_post(5,:).*par_post(1,:).*par_post(6,:) + (1-par_post(5,:)).*par_post(2,:).*par_post(1,:).*par_post(6,:);
 mean(Re)

figure
subplot(3,1,1)
histogram(par_post(1,:))
subplot(3,1,2)
histogram(par_post(5,:))
subplot(3,1,3)
histogram(Re)

%Create Data
Rep_num(w,:) = Re;
alpha(w,:)=par_post(5,:);



%run SEIR with the parameters
predict_6()
load predict_results_6







%7th week
w=7
load incidence_6
a=incidence(end,:);
inc = readtable(filename,'ReadVariableNames',true);
inc.Country_Region = string(inc.Country_Region);
incidence = zeros(7,5);
incidence(1,:)=a;
incidence_cum = zeros(7,5) ;

ct = string(cities);
for i=1:5
    l = find(inc.Country_Region==ct(i));
    
    incidence_cum(:,i)=table2array(inc(l,(weeks(w,1):weeks(w,2))));
end

for i=2:7
    incidence(i,:) = incidence_cum(i,:)-incidence_cum(i-1,:);
end
save incidence_7 incidence


%initialization
inference_7()


load parameters_7
 Re=parameters(5)*parameters(1)*parameters(6) + (1-parameters(5))*parameters(2)*parameters(1)*parameters(6)
parameters
 load x_post_7
 par_post = mean(x_post(end-5:end,:,:),3);

 Re=par_post(5,:).*par_post(1,:).*par_post(6,:) + (1-par_post(5,:)).*par_post(2,:).*par_post(1,:).*par_post(6,:);
 mean(Re)

figure
subplot(3,1,1)
histogram(par_post(1,:))
subplot(3,1,2)
histogram(par_post(5,:))
subplot(3,1,3)
histogram(Re)

%Create Data
Rep_num(w,:) = Re;
alpha(w,:)=par_post(5,:);



%run SEIR with the parameters
predict_7()
load predict_results_7




%8th week
w=8
load incidence_7
a=incidence(end,:);
inc = readtable(filename,'ReadVariableNames',true);
inc.Country_Region = string(inc.Country_Region);
incidence = zeros(7,5);
incidence(1,:)=a;
incidence_cum = zeros(7,5) ;

ct = string(cities);
for i=1:5
    l = find(inc.Country_Region==ct(i));
    
    incidence_cum(:,i)=table2array(inc(l,(weeks(w,1):weeks(w,2))));
end

for i=2:7
    incidence(i,:) = incidence_cum(i,:)-incidence_cum(i-1,:);
end
save incidence_8 incidence


%initialization
inference_8()


load parameters_8
 Re=parameters(5)*parameters(1)*parameters(6) + (1-parameters(5))*parameters(2)*parameters(1)*parameters(6)
parameters
 load x_post_8
 par_post = mean(x_post(end-5:end,:,:),3);

 Re=par_post(5,:).*par_post(1,:).*par_post(6,:) + (1-par_post(5,:)).*par_post(2,:).*par_post(1,:).*par_post(6,:);
 mean(Re)

figure
subplot(3,1,1)
histogram(par_post(1,:))
subplot(3,1,2)
histogram(par_post(5,:))
subplot(3,1,3)
histogram(Re)

%Create Data
Rep_num(w,:) = Re;
alpha(w,:)=par_post(5,:);



%run SEIR with the parameters
predict_8()
load predict_results_8





%9th week
w=9
load incidence_8
a=incidence(end,:);
inc = readtable(filename,'ReadVariableNames',true)
inc.Country_Region = string(inc.Country_Region);
incidence = zeros(7,5)
incidence(1,:)=a;
incidence_cum = zeros(7,5) ;

ct = string(cities);
for i=1:5
    l = find(inc.Country_Region==ct(i));
    
    incidence_cum(:,i)=table2array(inc(l,(weeks(w,1):weeks(w,2))));
end

for i=2:7
    incidence(i,:) = incidence_cum(i,:)-incidence_cum(i-1,:);
end
save incidence_9 incidence


%initialization
inference_9()


load parameters_9
 Re=parameters(5)*parameters(1)*parameters(6) + (1-parameters(5))*parameters(2)*parameters(1)*parameters(6)
parameters
 load x_post_9
 par_post = mean(x_post(end-5:end,:,:),3);

 Re=par_post(5,:).*par_post(1,:).*par_post(6,:) + (1-par_post(5,:)).*par_post(2,:).*par_post(1,:).*par_post(6,:);
 mean(Re)

figure
subplot(3,1,1)
histogram(par_post(1,:))
subplot(3,1,2)
histogram(par_post(5,:))
subplot(3,1,3)
histogram(Re)

%Create Data
Rep_num(w,:) = Re;
alpha(w,:)=par_post(5,:);



%run SEIR with the parameters
predict_9()
load predict_results_9



%10th week
w=10
load incidence_9
a=incidence(end,:);
inc = readtable(filename,'ReadVariableNames',true);
inc.Country_Region = string(inc.Country_Region);
incidence = zeros(7,5);
incidence(1,:)=a;
incidence_cum = zeros(7,5) ;

ct = string(cities);
for i=1:5
    l = find(inc.Country_Region==ct(i));
    
    incidence_cum(:,i)=table2array(inc(l,(weeks(w,1):weeks(w,2))));
end

for i=2:7
    incidence(i,:) = incidence_cum(i,:)-incidence_cum(i-1,:);
end
save incidence_10 incidence


%initialization
inference_10()


load parameters_10
 Re=parameters(5)*parameters(1)*parameters(6) + (1-parameters(5))*parameters(2)*parameters(1)*parameters(6)
parameters
 load x_post_10
 par_post = mean(x_post(end-5:end,:,:),3);

 Re=par_post(5,:).*par_post(1,:).*par_post(6,:) + (1-par_post(5,:)).*par_post(2,:).*par_post(1,:).*par_post(6,:);
 mean(Re)

figure
subplot(3,1,1)
histogram(par_post(1,:))
subplot(3,1,2)
histogram(par_post(5,:))
subplot(3,1,3)
histogram(Re)

%Create Data
Rep_num(w,:) = Re;
alpha(w,:)=par_post(5,:);



%run SEIR with the parameters
predict_10()
load predict_results_10



%11th week
w=11;
load incidence_10
a=incidence(end,:);
inc = readtable(filename,'ReadVariableNames',true);
inc.Country_Region = string(inc.Country_Region);
incidence = zeros(7,5)
incidence(1,:)=a;
incidence_cum = zeros(7,5) ;

ct = string(cities);
for i=1:5
    l = find(inc.Country_Region==ct(i));
    
    incidence_cum(:,i)=table2array(inc(l,(weeks(w,1):weeks(w,2))));
end

for i=2:7
    incidence(i,:) = incidence_cum(i,:)-incidence_cum(i-1,:);
end
save incidence_11 incidence


%initialization
inference_11()


load parameters_11
 Re=parameters(5)*parameters(1)*parameters(6) + (1-parameters(5))*parameters(2)*parameters(1)*parameters(6)
parameters
 load x_post_11
 par_post = mean(x_post(end-5:end,:,:),3);

 Re=par_post(5,:).*par_post(1,:).*par_post(6,:) + (1-par_post(5,:)).*par_post(2,:).*par_post(1,:).*par_post(6,:);
 mean(Re)

figure
subplot(3,1,1)
histogram(par_post(1,:))
subplot(3,1,2)
histogram(par_post(5,:))
subplot(3,1,3)
histogram(Re)

%Create Data
Rep_num(w,:) = Re;
alpha(w,:)=par_post(5,:);



%run SEIR with the parameters
predict_11()
load predict_results_11




%12th week
w=12;
load incidence_11
a=incidence(end,:);
inc = readtable(filename,'ReadVariableNames',true);
inc.Country_Region = string(inc.Country_Region);
incidence = zeros(7,5);
incidence(1,:)=a;
incidence_cum = zeros(7,5) ;

ct = string(cities);
for i=1:5
    l = find(inc.Country_Region==ct(i));
    
    incidence_cum(:,i)=table2array(inc(l,(weeks(w,1):weeks(w,2))));
end

for i=2:7
    incidence(i,:) = incidence_cum(i,:)-incidence_cum(i-1,:);
end
save incidence_12 incidence


%initialization
inference_12()


load parameters_12
 Re=parameters(5)*parameters(1)*parameters(6) + (1-parameters(5))*parameters(2)*parameters(1)*parameters(6)
parameters
 load x_post_12
 par_post = mean(x_post(end-5:end,:,:),3);

 Re=par_post(5,:).*par_post(1,:).*par_post(6,:) + (1-par_post(5,:)).*par_post(2,:).*par_post(1,:).*par_post(6,:);
 mean(Re)

figure
subplot(3,1,1)
histogram(par_post(1,:))
subplot(3,1,2)
histogram(par_post(5,:))
subplot(3,1,3)
histogram(Re)

%Create Data
Rep_num(w,:) = Re;
alpha(w,:)=par_post(5,:);



%run SEIR with the parameters
predict_12()
load predict_results_12




%13th week
w=13;
load incidence_12
a=incidence(end,:);
inc = readtable(filename,'ReadVariableNames',true);
inc.Country_Region = string(inc.Country_Region);
incidence = zeros(7,5);
incidence(1,:)=a;
incidence_cum = zeros(7,5) ;

ct = string(cities);
for i=1:5
    l = find(inc.Country_Region==ct(i));
    
    incidence_cum(:,i)=table2array(inc(l,(weeks(w,1):weeks(w,2))));
end

for i=2:7
    incidence(i,:) = incidence_cum(i,:)-incidence_cum(i-1,:);
end
save incidence_13 incidence


%initialization
inference_13()


load parameters_13
 Re=parameters(5)*parameters(1)*parameters(6) + (1-parameters(5))*parameters(2)*parameters(1)*parameters(6)
parameters
 load x_post_13
 par_post = mean(x_post(end-5:end,:,:),3);

 Re=par_post(5,:).*par_post(1,:).*par_post(6,:) + (1-par_post(5,:)).*par_post(2,:).*par_post(1,:).*par_post(6,:);
 mean(Re)

figure
subplot(3,1,1)
histogram(par_post(1,:))
subplot(3,1,2)
histogram(par_post(5,:))
subplot(3,1,3)
histogram(Re)

%Create Data
Rep_num(w,:) = Re;
alpha(w,:)=par_post(5,:);



%run SEIR with the parameters
predict_13()
load predict_results_13




%14th week
w=14;
load incidence_13
a=incidence(end,:);
inc = readtable(filename,'ReadVariableNames',true);
inc.Country_Region = string(inc.Country_Region);
incidence = zeros(7,5);
incidence(1,:)=a;
incidence_cum = zeros(7,5) ;

ct = string(cities);
for i=1:5
    l = find(inc.Country_Region==ct(i));
    
    incidence_cum(:,i)=table2array(inc(l,(weeks(w,1):weeks(w,2))));
end

for i=2:7
    incidence(i,:) = incidence_cum(i,:)-incidence_cum(i-1,:);
end
save incidence_14 incidence


%initialization
inference_14()


load parameters_14
 Re=parameters(5)*parameters(1)*parameters(6) + (1-parameters(5))*parameters(2)*parameters(1)*parameters(6)
parameters
 load x_post_14
 par_post = mean(x_post(end-5:end,:,:),3);

 Re=par_post(5,:).*par_post(1,:).*par_post(6,:) + (1-par_post(5,:)).*par_post(2,:).*par_post(1,:).*par_post(6,:);
 mean(Re)

figure
subplot(3,1,1)
histogram(par_post(1,:))
subplot(3,1,2)
histogram(par_post(5,:))
subplot(3,1,3)
histogram(Re)

%Create Data
Rep_num(w,:) = Re;
alpha(w,:)=par_post(5,:);



%run SEIR with the parameters
predict_14()
load predict_results_14




%15th week
w=15;
load incidence_14
a=incidence(end,:);
inc = readtable(filename,'ReadVariableNames',true);
inc.Country_Region = string(inc.Country_Region);
incidence = zeros(7,5);
incidence(1,:)=a;
incidence_cum = zeros(7,5) ;

ct = string(cities);
for i=1:5
    l = find(inc.Country_Region==ct(i));
    
    incidence_cum(:,i)=table2array(inc(l,(weeks(w,1):weeks(w,2))));
end

for i=2:7
    incidence(i,:) = incidence_cum(i,:)-incidence_cum(i-1,:);
end
save incidence_15 incidence


%initialization
inference_15()


load parameters_15
 Re=parameters(5)*parameters(1)*parameters(6) + (1-parameters(5))*parameters(2)*parameters(1)*parameters(6)
parameters
 load x_post_15
 par_post = mean(x_post(end-5:end,:,:),3);

 Re=par_post(5,:).*par_post(1,:).*par_post(6,:) + (1-par_post(5,:)).*par_post(2,:).*par_post(1,:).*par_post(6,:);
 mean(Re)

figure
subplot(3,1,1)
histogram(par_post(1,:))
subplot(3,1,2)
histogram(par_post(5,:))
subplot(3,1,3)
histogram(Re)

%Create Data
Rep_num(w,:) = Re;
alpha(w,:)=par_post(5,:);



%run SEIR with the parameters
predict_15()
load predict_results_15




%16th week
w=16;
load incidence_15
a=incidence(end,:);
inc = readtable(filename,'ReadVariableNames',true);
inc.Country_Region = string(inc.Country_Region);
incidence = zeros(7,5);
incidence(1,:)=a;
incidence_cum = zeros(7,5) ;

ct = string(cities);
for i=1:5
    l = find(inc.Country_Region==ct(i));
    
    incidence_cum(:,i)=table2array(inc(l,(weeks(w,1):weeks(w,2))));
end

for i=2:7
    incidence(i,:) = incidence_cum(i,:)-incidence_cum(i-1,:);
end
save incidence_16 incidence


%initialization
inference_16()


load parameters_16
 Re=parameters(5)*parameters(1)*parameters(6) + (1-parameters(5))*parameters(2)*parameters(1)*parameters(6)
parameters
 load x_post_16
 par_post = mean(x_post(end-5:end,:,:),3);

 Re=par_post(5,:).*par_post(1,:).*par_post(6,:) + (1-par_post(5,:)).*par_post(2,:).*par_post(1,:).*par_post(6,:);
 mean(Re)

figure
subplot(3,1,1)
histogram(par_post(1,:))
subplot(3,1,2)
histogram(par_post(5,:))
subplot(3,1,3)
histogram(Re)

%Create Data
Rep_num(w,:) = Re;
alpha(w,:)=par_post(5,:);



%run SEIR with the parameters
predict_16()
load predict_results_16



%17th week
w=17;
load incidence_16
a=incidence(end,:);
inc = readtable(filename,'ReadVariableNames',true);
inc.Country_Region = string(inc.Country_Region);
incidence = zeros(7,5);
incidence(1,:)=a;
incidence_cum = zeros(7,5) ;

ct = string(cities);
for i=1:5
    l = find(inc.Country_Region==ct(i));
    
    incidence_cum(:,i)=table2array(inc(l,(weeks(w,1):weeks(w,2))));
end

for i=2:7
    incidence(i,:) = incidence_cum(i,:)-incidence_cum(i-1,:);
end
save incidence_17 incidence


%initialization
inference_17()


load parameters_17
 Re=parameters(5)*parameters(1)*parameters(6) + (1-parameters(5))*parameters(2)*parameters(1)*parameters(6)
parameters
 load x_post_17
 par_post = mean(x_post(end-5:end,:,:),3);

 Re=par_post(5,:).*par_post(1,:).*par_post(6,:) + (1-par_post(5,:)).*par_post(2,:).*par_post(1,:).*par_post(6,:);
 mean(Re)

figure
subplot(3,1,1)
histogram(par_post(1,:))
subplot(3,1,2)
histogram(par_post(5,:))
subplot(3,1,3)
histogram(Re)

%Create Data
Rep_num(w,:) = Re;
alpha(w,:)=par_post(5,:);



%run SEIR with the parameters
predict_17()
load predict_results_17




%18th week
w=18;
load incidence_17
a=incidence(end,:);
inc = readtable(filename,'ReadVariableNames',true);
inc.Country_Region = string(inc.Country_Region);
incidence = zeros(7,5);
incidence(1,:)=a;
incidence_cum = zeros(7,5) ;

ct = string(cities);
for i=1:5
    l = find(inc.Country_Region==ct(i));
    
    incidence_cum(:,i)=table2array(inc(l,(weeks(w,1):weeks(w,2))));
end

for i=2:7
    incidence(i,:) = incidence_cum(i,:)-incidence_cum(i-1,:);
end
save incidence_18 incidence


%initialization
inference_18()


load parameters_18
 Re=parameters(5)*parameters(1)*parameters(6) + (1-parameters(5))*parameters(2)*parameters(1)*parameters(6)
parameters
 load x_post_18
 par_post = mean(x_post(end-5:end,:,:),3);

 Re=par_post(5,:).*par_post(1,:).*par_post(6,:) + (1-par_post(5,:)).*par_post(2,:).*par_post(1,:).*par_post(6,:);
 mean(Re)

figure
subplot(3,1,1)
histogram(par_post(1,:))
subplot(3,1,2)
histogram(par_post(5,:))
subplot(3,1,3)
histogram(Re)

%Create Data
Rep_num(w,:) = Re;
alpha(w,:)=par_post(5,:);



%run SEIR with the parameters
predict_18()
load predict_results_18



%19th week
w=19;
load incidence_18
a=incidence(end,:);
inc = readtable(filename,'ReadVariableNames',true);
inc.Country_Region = string(inc.Country_Region);
incidence = zeros(7,5);
incidence(1,:)=a;
incidence_cum = zeros(7,5) ;

ct = string(cities);
for i=1:5
    l = find(inc.Country_Region==ct(i));
    
    incidence_cum(:,i)=table2array(inc(l,(weeks(w,1):weeks(w,2))));
end

for i=2:7
    incidence(i,:) = incidence_cum(i,:)-incidence_cum(i-1,:);
end
save incidence_19 incidence


%initialization
inference_19()


load parameters_19
 Re=parameters(5)*parameters(1)*parameters(6) + (1-parameters(5))*parameters(2)*parameters(1)*parameters(6)
parameters
 load x_post_19
 par_post = mean(x_post(end-5:end,:,:),3);

 Re=par_post(5,:).*par_post(1,:).*par_post(6,:) + (1-par_post(5,:)).*par_post(2,:).*par_post(1,:).*par_post(6,:);
 mean(Re)

figure
subplot(3,1,1)
histogram(par_post(1,:))
subplot(3,1,2)
histogram(par_post(5,:))
subplot(3,1,3)
histogram(Re)

%Create Data
Rep_num(w,:) = Re;
alpha(w,:)=par_post(5,:);



%run SEIR with the parameters
predict_19()
load predict_results_19



%20th week
w=20;
load incidence_19
a=incidence(end,:);
inc = readtable(filename,'ReadVariableNames',true);
inc.Country_Region = string(inc.Country_Region);
incidence = zeros(7,5);
incidence(1,:)=a;
incidence_cum = zeros(7,5) ;

ct = string(cities);
for i=1:5
    l = find(inc.Country_Region==ct(i));
    
    incidence_cum(:,i)=table2array(inc(l,(weeks(w,1):weeks(w,2))));
end

for i=2:7
    incidence(i,:) = incidence_cum(i,:)-incidence_cum(i-1,:);
end
save incidence_20 incidence


%initialization
inference_20()


load parameters_20
 Re=parameters(5)*parameters(1)*parameters(6) + (1-parameters(5))*parameters(2)*parameters(1)*parameters(6)
parameters
 load x_post_20
 par_post = mean(x_post(end-5:end,:,:),3);

 Re=par_post(5,:).*par_post(1,:).*par_post(6,:) + (1-par_post(5,:)).*par_post(2,:).*par_post(1,:).*par_post(6,:);
 mean(Re)

figure
subplot(3,1,1)
histogram(par_post(1,:))
subplot(3,1,2)
histogram(par_post(5,:))
subplot(3,1,3)
histogram(Re)

%Create Data
Rep_num(w,:) = Re;
alpha(w,:)=par_post(5,:);



%run SEIR with the parameters
predict_20()
load predict_results_20



%21th week
w=21;
load incidence_20
a=incidence(end,:);
inc = readtable(filename,'ReadVariableNames',true);
inc.Country_Region = string(inc.Country_Region);
incidence = zeros(7,5);
incidence(1,:)=a;
incidence_cum = zeros(7,5) ;

ct = string(cities);
for i=1:5
    l = find(inc.Country_Region==ct(i));
    
    incidence_cum(:,i)=table2array(inc(l,(weeks(w,1):weeks(w,2))));
end

for i=2:7
    incidence(i,:) = incidence_cum(i,:)-incidence_cum(i-1,:);
end
save incidence_21 incidence


%initialization
inference_21()


load parameters_21
 Re=parameters(5)*parameters(1)*parameters(6) + (1-parameters(5))*parameters(2)*parameters(1)*parameters(6)
parameters
 load x_post_21
 par_post = mean(x_post(end-5:end,:,:),3);

 Re=par_post(5,:).*par_post(1,:).*par_post(6,:) + (1-par_post(5,:)).*par_post(2,:).*par_post(1,:).*par_post(6,:);
 mean(Re)

figure
subplot(3,1,1)
histogram(par_post(1,:))
subplot(3,1,2)
histogram(par_post(5,:))
subplot(3,1,3)
histogram(Re)

%Create Data
Rep_num(w,:) = Re;
alpha(w,:)=par_post(5,:);



%run SEIR with the parameters
predict_21()
load predict_results_21



%22th week
w=22;
load incidence_21
a=incidence(end,:);
inc = readtable(filename,'ReadVariableNames',true);
inc.Country_Region = string(inc.Country_Region);
incidence = zeros(7,5);
incidence(1,:)=a;
incidence_cum = zeros(7,5) ;

ct = string(cities);
for i=1:5
    l = find(inc.Country_Region==ct(i));
    
    incidence_cum(:,i)=table2array(inc(l,(weeks(w,1):weeks(w,2))));
end

for i=2:7
    incidence(i,:) = incidence_cum(i,:)-incidence_cum(i-1,:);
end
save incidence_22 incidence


%initialization
inference_22()


load parameters_22
 Re=parameters(5)*parameters(1)*parameters(6) + (1-parameters(5))*parameters(2)*parameters(1)*parameters(6)
parameters
 load x_post_22
 par_post = mean(x_post(end-5:end,:,:),3);

 Re=par_post(5,:).*par_post(1,:).*par_post(6,:) + (1-par_post(5,:)).*par_post(2,:).*par_post(1,:).*par_post(6,:);
 mean(Re)

figure
subplot(3,1,1)
histogram(par_post(1,:))
subplot(3,1,2)
histogram(par_post(5,:))
subplot(3,1,3)
histogram(Re)

%Create Data
Rep_num(w,:) = Re;
alpha(w,:)=par_post(5,:);



%run SEIR with the parameters
predict_22()
load predict_results_22



%23th week
w=23;
load incidence_22
a=incidence(end,:);
inc = readtable(filename,'ReadVariableNames',true);
inc.Country_Region = string(inc.Country_Region);
incidence = zeros(7,5);
incidence(1,:)=a;
incidence_cum = zeros(7,5) ;

ct = string(cities);
for i=1:5
    l = find(inc.Country_Region==ct(i));
    
    incidence_cum(:,i)=table2array(inc(l,(weeks(w,1):weeks(w,2))));
end

for i=2:7
    incidence(i,:) = incidence_cum(i,:)-incidence_cum(i-1,:);
end
save incidence_23 incidence


%initialization
inference_23()


load parameters_23
 Re=parameters(5)*parameters(1)*parameters(6) + (1-parameters(5))*parameters(2)*parameters(1)*parameters(6)
parameters
 load x_post_23
 par_post = mean(x_post(end-5:end,:,:),3);

 Re=par_post(5,:).*par_post(1,:).*par_post(6,:) + (1-par_post(5,:)).*par_post(2,:).*par_post(1,:).*par_post(6,:);
 mean(Re)

figure
subplot(3,1,1)
histogram(par_post(1,:))
subplot(3,1,2)
histogram(par_post(5,:))
subplot(3,1,3)
histogram(Re)

%Create Data
Rep_num(w,:) = Re;
alpha(w,:)=par_post(5,:);



%run SEIR with the parameters
predict_23()
load predict_results_23



%24th week
w=24;
load incidence_23
a=incidence(end,:);
inc = readtable(filename,'ReadVariableNames',true);
inc.Country_Region = string(inc.Country_Region);
incidence = zeros(7,5);
incidence(1,:)=a;
incidence_cum = zeros(7,5) ;

ct = string(cities);
for i=1:5
    l = find(inc.Country_Region==ct(i));
    
    incidence_cum(:,i)=table2array(inc(l,(weeks(w,1):weeks(w,2))));
end

for i=2:7
    incidence(i,:) = incidence_cum(i,:)-incidence_cum(i-1,:);
end
save incidence_24 incidence


%initialization
inference_24()


load parameters_24
 Re=parameters(5)*parameters(1)*parameters(6) + (1-parameters(5))*parameters(2)*parameters(1)*parameters(6)
parameters
 load x_post_24
 par_post = mean(x_post(end-5:end,:,:),3);

 Re=par_post(5,:).*par_post(1,:).*par_post(6,:) + (1-par_post(5,:)).*par_post(2,:).*par_post(1,:).*par_post(6,:);
 mean(Re)

figure
subplot(3,1,1)
histogram(par_post(1,:))
subplot(3,1,2)
histogram(par_post(5,:))
subplot(3,1,3)
histogram(Re)

%Create Data
Rep_num(w,:) = Re;
alpha(w,:)=par_post(5,:);



%run SEIR with the parameters
predict_24()
load predict_results_24





%25th week
w=25;
load incidence_24
a=incidence(end,:);
inc = readtable(filename,'ReadVariableNames',true);
inc.Country_Region = string(inc.Country_Region);
incidence = zeros(7,5);
incidence(1,:)=a;
incidence_cum = zeros(7,5) ;

ct = string(cities);
for i=1:5
    l = find(inc.Country_Region==ct(i));
    
    incidence_cum(:,i)=table2array(inc(l,(weeks(w,1):weeks(w,2))));
end

for i=2:7
    incidence(i,:) = incidence_cum(i,:)-incidence_cum(i-1,:);
end
save incidence_25 incidence


%initialization
inference_25()


load parameters_25
 Re=parameters(5)*parameters(1)*parameters(6) + (1-parameters(5))*parameters(2)*parameters(1)*parameters(6)
parameters
 load x_post_25
 par_post = mean(x_post(end-5:end,:,:),3);

 Re=par_post(5,:).*par_post(1,:).*par_post(6,:) + (1-par_post(5,:)).*par_post(2,:).*par_post(1,:).*par_post(6,:);
 mean(Re)

figure
subplot(3,1,1)
histogram(par_post(1,:))
subplot(3,1,2)
histogram(par_post(5,:))
subplot(3,1,3)
histogram(Re)

%Create Data
Rep_num(w,:) = Re;
alpha(w,:)=par_post(5,:);



%run SEIR with the parameters
predict_25()
load predict_results_25




%25th week
w=26;
load incidence_25
a=incidence(end,:);
inc = readtable(filename,'ReadVariableNames',true);
inc.Country_Region = string(inc.Country_Region);
incidence = zeros(7,5);
incidence(1,:)=a;
incidence_cum = zeros(7,5) ;

ct = string(cities);
for i=1:5
    l = find(inc.Country_Region==ct(i));
    
    incidence_cum(:,i)=table2array(inc(l,(weeks(w,1):weeks(w,2))));
end

for i=2:7
    incidence(i,:) = incidence_cum(i,:)-incidence_cum(i-1,:);
end
save incidence_26 incidence


%initialization
inference_26()


load parameters_26
 Re=parameters(5)*parameters(1)*parameters(6) + (1-parameters(5))*parameters(2)*parameters(1)*parameters(6)
parameters
 load x_post_26
 par_post = mean(x_post(end-5:end,:,:),3);

 Re=par_post(5,:).*par_post(1,:).*par_post(6,:) + (1-par_post(5,:)).*par_post(2,:).*par_post(1,:).*par_post(6,:);
 mean(Re)

figure
subplot(3,1,1)
histogram(par_post(1,:))
subplot(3,1,2)
histogram(par_post(5,:))
subplot(3,1,3)
histogram(Re)

%Create Data
Rep_num(w,:) = Re;
alpha(w,:)=par_post(5,:);



%run SEIR with the parameters
predict_26()
load predict_results_26




%27th week
w=27;
load incidence_26
a=incidence(end,:);
inc = readtable(filename,'ReadVariableNames',true);
inc.Country_Region = string(inc.Country_Region);
incidence = zeros(7,5);
incidence(1,:)=a;
incidence_cum = zeros(7,5) ;

ct = string(cities);
for i=1:5
    l = find(inc.Country_Region==ct(i));
    
    incidence_cum(:,i)=table2array(inc(l,(weeks(w,1):weeks(w,2))));
end

for i=2:7
    incidence(i,:) = incidence_cum(i,:)-incidence_cum(i-1,:);
end
save incidence_27 incidence


%initialization
inference_27()


load parameters_27
 Re=parameters(5)*parameters(1)*parameters(6) + (1-parameters(5))*parameters(2)*parameters(1)*parameters(6)
parameters
 load x_post_27
 par_post = mean(x_post(end-5:end,:,:),3);

 Re=par_post(5,:).*par_post(1,:).*par_post(6,:) + (1-par_post(5,:)).*par_post(2,:).*par_post(1,:).*par_post(6,:);
 mean(Re)

figure
subplot(3,1,1)
histogram(par_post(1,:))
subplot(3,1,2)
histogram(par_post(5,:))
subplot(3,1,3)
histogram(Re)

%Create Data
Rep_num(w,:) = Re;
alpha(w,:)=par_post(5,:);



%run SEIR with the parameters
predict_27()
load predict_results_27




%28th week
w=28;
load incidence_27
a=incidence(end,:);
inc = readtable(filename,'ReadVariableNames',true);
inc.Country_Region = string(inc.Country_Region);
incidence = zeros(7,5);
incidence(1,:)=a;
incidence_cum = zeros(7,5) ;

ct = string(cities);
for i=1:5
    l = find(inc.Country_Region==ct(i));
    
    incidence_cum(:,i)=table2array(inc(l,(weeks(w,1):weeks(w,2))));
end

for i=2:7
    incidence(i,:) = incidence_cum(i,:)-incidence_cum(i-1,:);
end
save incidence_28 incidence


%initialization
inference_28()


load parameters_28
 Re=parameters(5)*parameters(1)*parameters(6) + (1-parameters(5))*parameters(2)*parameters(1)*parameters(6)
parameters
 load x_post_28
 par_post = mean(x_post(end-5:end,:,:),3);

 Re=par_post(5,:).*par_post(1,:).*par_post(6,:) + (1-par_post(5,:)).*par_post(2,:).*par_post(1,:).*par_post(6,:);
 mean(Re)

figure
subplot(3,1,1)
histogram(par_post(1,:))
subplot(3,1,2)
histogram(par_post(5,:))
subplot(3,1,3)
histogram(Re)

%Create Data
Rep_num(w,:) = Re;
alpha(w,:)=par_post(5,:);



%run SEIR with the parameters
predict_28()
load predict_results_28




%29th week
w=29;
load incidence_28
a=incidence(end,:);
inc = readtable(filename,'ReadVariableNames',true);
inc.Country_Region = string(inc.Country_Region);
incidence = zeros(7,5);
incidence(1,:)=a;
incidence_cum = zeros(7,5) ;

ct = string(cities);
for i=1:5
    l = find(inc.Country_Region==ct(i));
    
    incidence_cum(:,i)=table2array(inc(l,(weeks(w,1):weeks(w,2))));
end

for i=2:7
    incidence(i,:) = incidence_cum(i,:)-incidence_cum(i-1,:);
end
save incidence_29 incidence


%initialization
inference_29()


load parameters_29
 Re=parameters(5)*parameters(1)*parameters(6) + (1-parameters(5))*parameters(2)*parameters(1)*parameters(6)
parameters
 load x_post_29
 par_post = mean(x_post(end-5:end,:,:),3);

 Re=par_post(5,:).*par_post(1,:).*par_post(6,:) + (1-par_post(5,:)).*par_post(2,:).*par_post(1,:).*par_post(6,:);
 mean(Re)

figure
subplot(3,1,1)
histogram(par_post(1,:))
subplot(3,1,2)
histogram(par_post(5,:))
subplot(3,1,3)
histogram(Re)

%Create Data
Rep_num(w,:) = Re;
alpha(w,:)=par_post(5,:);



%run SEIR with the parameters
predict_29()
load predict_results_29




%30th week
w=30;
load incidence_29
a=incidence(end,:);
inc = readtable(filename,'ReadVariableNames',true);
inc.Country_Region = string(inc.Country_Region);
incidence = zeros(7,5);
incidence(1,:)=a;
incidence_cum = zeros(7,5) ;

ct = string(cities);
for i=1:5
    l = find(inc.Country_Region==ct(i));
    
    incidence_cum(:,i)=table2array(inc(l,(weeks(w,1):weeks(w,2))));
end

for i=2:7
    incidence(i,:) = incidence_cum(i,:)-incidence_cum(i-1,:);
end
save incidence_30 incidence


%initialization
inference_30()


load parameters_30
 Re=parameters(5)*parameters(1)*parameters(6) + (1-parameters(5))*parameters(2)*parameters(1)*parameters(6)
parameters
 load x_post_30
 par_post = mean(x_post(end-5:end,:,:),3);

 Re=par_post(5,:).*par_post(1,:).*par_post(6,:) + (1-par_post(5,:)).*par_post(2,:).*par_post(1,:).*par_post(6,:);
 mean(Re)

figure
subplot(3,1,1)
histogram(par_post(1,:))
subplot(3,1,2)
histogram(par_post(5,:))
subplot(3,1,3)
histogram(Re)

%Create Data
Rep_num(w,:) = Re;
alpha(w,:)=par_post(5,:);



%run SEIR with the parameters
predict_30()
load predict_results_30



%31th week
w=31;
load incidence_30
a=incidence(end,:);
inc = readtable(filename,'ReadVariableNames',true);
inc.Country_Region = string(inc.Country_Region);
incidence = zeros(7,5);
incidence(1,:)=a;
incidence_cum = zeros(7,5) ;

ct = string(cities);
for i=1:5
    l = find(inc.Country_Region==ct(i));
    
    incidence_cum(:,i)=table2array(inc(l,(weeks(w,1):weeks(w,2))));
end

for i=2:7
    incidence(i,:) = incidence_cum(i,:)-incidence_cum(i-1,:);
end
save incidence_31 incidence


%initialization
inference_31()


load parameters_31
 Re=parameters(5)*parameters(1)*parameters(6) + (1-parameters(5))*parameters(2)*parameters(1)*parameters(6)
parameters
 load x_post_31
 par_post = mean(x_post(end-5:end,:,:),3);

 Re=par_post(5,:).*par_post(1,:).*par_post(6,:) + (1-par_post(5,:)).*par_post(2,:).*par_post(1,:).*par_post(6,:);
 mean(Re)

figure
subplot(3,1,1)
histogram(par_post(1,:))
subplot(3,1,2)
histogram(par_post(5,:))
subplot(3,1,3)
histogram(Re)

%Create Data
Rep_num(w,:) = Re;
alpha(w,:)=par_post(5,:);



%run SEIR with the parameters
predict_31()
load predict_results_31



%32th week
w=32;
load incidence_31
a=incidence(end,:);
inc = readtable(filename,'ReadVariableNames',true);
inc.Country_Region = string(inc.Country_Region);
incidence = zeros(7,5);
incidence(1,:)=a;
incidence_cum = zeros(7,5) ;

ct = string(cities);
for i=1:5
    l = find(inc.Country_Region==ct(i));
    
    incidence_cum(:,i)=table2array(inc(l,(weeks(w,1):weeks(w,2))));
end

for i=2:7
    incidence(i,:) = incidence_cum(i,:)-incidence_cum(i-1,:);
end
save incidence_32 incidence


%initialization
inference_32()


load parameters_32
 Re=parameters(5)*parameters(1)*parameters(6) + (1-parameters(5))*parameters(2)*parameters(1)*parameters(6)
parameters
 load x_post_32
 par_post = mean(x_post(end-5:end,:,:),3);

 Re=par_post(5,:).*par_post(1,:).*par_post(6,:) + (1-par_post(5,:)).*par_post(2,:).*par_post(1,:).*par_post(6,:);
 mean(Re)

figure
subplot(3,1,1)
histogram(par_post(1,:))
subplot(3,1,2)
histogram(par_post(5,:))
subplot(3,1,3)
histogram(Re)

%Create Data
Rep_num(w,:) = Re;
alpha(w,:)=par_post(5,:);



%run SEIR with the parameters
predict_32()
load predict_results_32



%33th week
w=33;
load incidence_32
a=incidence(end,:);
inc = readtable(filename,'ReadVariableNames',true);
inc.Country_Region = string(inc.Country_Region);
incidence = zeros(7,5);
incidence(1,:)=a;
incidence_cum = zeros(7,5) ;

ct = string(cities);
for i=1:5
    l = find(inc.Country_Region==ct(i));
    
    incidence_cum(:,i)=table2array(inc(l,(weeks(w,1):weeks(w,2))));
end

for i=2:7
    incidence(i,:) = incidence_cum(i,:)-incidence_cum(i-1,:);
end
save incidence_33 incidence


%initialization
inference_33()


load parameters_33
 Re=parameters(5)*parameters(1)*parameters(6) + (1-parameters(5))*parameters(2)*parameters(1)*parameters(6)
parameters
 load x_post_33
 par_post = mean(x_post(end-5:end,:,:),3);

 Re=par_post(5,:).*par_post(1,:).*par_post(6,:) + (1-par_post(5,:)).*par_post(2,:).*par_post(1,:).*par_post(6,:);
 mean(Re)

figure
subplot(3,1,1)
histogram(par_post(1,:))
subplot(3,1,2)
histogram(par_post(5,:))
subplot(3,1,3)
histogram(Re)

%Create Data
Rep_num(w,:) = Re;
alpha(w,:)=par_post(5,:);



%run SEIR with the parameters
predict_33()
load predict_results_33






figure
boxplot(Rep_num','Labels',Wname)
xtickangle(45)
ylim([0 5]);
hold on
y = 1;
line([0,1],[y,y])


figure
boxplot(alpha')

